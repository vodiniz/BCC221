#include <iostream>

#include "data.h"
#include "horario.h"
#include "ponto.h"
#include "chefe.h"
#include "vendedor.h"
#include "supervisor.h"
#include "menu.h"

using namespace std;

int main() {

    Menu menu;
    menu.login();
    
    return 0;
}